$('#js-nav-trigger').on('click', function () {
  $('.nav-links').toggleClass('open');
});
